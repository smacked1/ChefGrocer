# ChefGrocer iOS App

A simple iOS WebView wrapper for the ChefGrocer AI Chef app.

- Loads: https://chef-grocer-dxmyles123.replit.app
- Built in Swift
- For iOS 13+
